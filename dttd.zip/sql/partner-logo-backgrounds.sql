ALTER TABLE partners
ADD COLUMN logo_background ENUM('dark','light') NOT NULL DEFAULT 'dark'
AFTER image_url;
