ALTER TABLE partners
MODIFY COLUMN logo_background ENUM('dark','light','neon_pink','starburst','radial_neon') NOT NULL DEFAULT 'dark';

ALTER TABLE sponsors
MODIFY COLUMN logo_background ENUM('dark','light','neon_pink','starburst','radial_neon') NOT NULL DEFAULT 'dark';
