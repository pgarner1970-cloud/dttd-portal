ALTER TABLE sponsors
ADD COLUMN logo_background ENUM('dark','light') NOT NULL DEFAULT 'dark'
AFTER logo_url;
