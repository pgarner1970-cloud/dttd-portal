<?php
require_once __DIR__ . '/_auth.php';
require_once __DIR__ . '/../includes/simple-pdf.php';

function dttd_post_items() {
    $items = [];
    $descs = $_POST['line_description'] ?? [];
    $prices = $_POST['line_price'] ?? [];
    foreach ($descs as $i => $desc) {
        $desc = trim((string)$desc);
        $price = (float)($prices[$i] ?? 0);
        if ($desc !== '' && $price >= 0) {
            $items[] = ['description' => $desc, 'price' => number_format($price, 2, '.', '')];
        }
    }
    return $items ?: [['description' => 'Dance Thru The Decades DJ Entertainment Package', 'price' => '0.00']];
}

function dttd_pdf_money($amount) {
    return chr(163) . number_format((float)$amount, 2);
}

function dttd_pdf_event_date_time($eventDate, $startTime, $endTime) {
    $parts = [];
    if (!empty($eventDate)) {
        $ts = strtotime((string)$eventDate);
        $parts[] = $ts ? date('d/m/Y', $ts) : (string)$eventDate;
    } else {
        $parts[] = 'TBC';
    }

    $start = !empty($startTime) ? substr((string)$startTime, 0, 5) : '';
    $end = !empty($endTime) ? substr((string)$endTime, 0, 5) : '';
    if ($start !== '' && $end !== '') {
        $parts[] = $start . ' - ' . $end;
    } elseif ($start !== '') {
        $parts[] = 'from ' . $start;
    } elseif ($end !== '') {
        $parts[] = 'until ' . $end;
    }

    return implode(' ', $parts);
}

$mode = $_GET['mode'] ?? '';
$type = $_GET['type'] ?? 'quote';
$isPreview = $mode === 'preview';
$invoiceNumber = '';

if ($isPreview) {
    $items = dttd_post_items();
    $total = 0; foreach ($items as $item) { $total += (float)$item['price']; }
    $doc = [
        'number' => 'PREVIEW',
        'customer_name' => trim($_POST['customer_name'] ?? 'Preview Customer'),
        'customer_email' => trim($_POST['customer_email'] ?? ''),
        'customer_address' => trim($_POST['customer_address'] ?? ''),
        'event_description' => trim($_POST['event_description'] ?? 'Dance Thru The Decades Event'),
        'event_date' => trim($_POST['event_date'] ?? ''),
        'venue_id' => !empty($_POST['venue_id']) ? (int)$_POST['venue_id'] : null,
        'venue' => trim($_POST['venue'] ?? ''),
        'event_start_time' => trim($_POST['event_start_time'] ?? ''),
        'event_end_time' => trim($_POST['event_end_time'] ?? ''),
        'items' => $items,
        'notes' => trim($_POST['notes'] ?? ''),
        'total_amount' => $total,
        'deposit_percentage' => max(0, min(100, (float)($_POST['deposit_percentage'] ?? 20))),
        'deposit_due_date' => trim($_POST['deposit_due_date'] ?? ''),
        'balance_due_date' => trim($_POST['balance_due_date'] ?? ''),
        'balance_due_event_date' => !empty($_POST['balance_due_event_date']),
        'quote_date' => date('Y-m-d'),
    ];
} else {
    $id = (int)($_GET['id'] ?? 0);
    $stmt = db()->prepare('SELECT * FROM quotations WHERE id = ?');
    $stmt->execute([$id]);
    $q = $stmt->fetch();
    if (!$q) { http_response_code(404); echo 'Quotation not found'; exit; }
    if ($type === 'invoice') {
        $stmt = db()->prepare('SELECT * FROM invoices WHERE quotation_id = ? LIMIT 1');
        $stmt->execute([$id]);
        $inv = $stmt->fetch();
        if (!$inv) { http_response_code(404); echo 'Invoice not found'; exit; }
        $invoiceNumber = $inv['invoice_number'];
    }
    $doc = [
        'number' => $type === 'invoice' ? $invoiceNumber : $q['quote_number'],
        'customer_name' => $q['customer_name'],
        'customer_email' => $q['customer_email'],
        'customer_address' => $q['customer_address'],
        'event_description' => $q['event_description'],
        'event_date' => $q['event_date'],
        'venue_id' => $q['venue_id'] ?? null,
        'venue' => $q['venue'],
        'event_start_time' => $q['event_start_time'] ?? '',
        'event_end_time' => $q['event_end_time'] ?? '',
        'items' => json_decode($q['items_json'], true) ?: [],
        'notes' => $q['notes'],
        'total_amount' => $q['total_amount'],
        'deposit_percentage' => isset($q['deposit_percentage']) ? (float)$q['deposit_percentage'] : 20.00,
        'deposit_due_date' => $q['deposit_due_date'] ?? '',
        'balance_due_date' => $q['balance_due_date'] ?? '',
        'balance_due_event_date' => false,
        'quote_date' => !empty($q['created_at']) ? date('Y-m-d', strtotime($q['created_at'])) : date('Y-m-d'),
    ];
}

$title = $type === 'invoice' ? 'INVOICE' : 'QUOTATION';
if ($isPreview) { $title = 'TEST PREVIEW'; }

$pdf = new DttdSimplePdf();
$pdf->beginPage();
$logo = dirname(__DIR__) . '/assets/dttd-invoice-logo.jpg';
$footer = dirname(__DIR__) . '/assets/dttd-invoice-footer.jpg';

$purple = [0.29, 0.00, 0.33];
$orange = [1.00, 0.47, 0.11];
$softPurple = [0.985, 0.965, 1.000];
$softGold = [1.000, 0.940, 0.780];
$line = [0.78, 0.70, 0.86];
$dark = [0.08, 0.05, 0.12];

// Footer artwork: full A4 width using a safer crop of the Facebook banner so the central wording is visible.
if (is_file($footer)) { $pdf->imageContain($footer, 0, 0, 595.28, 140); }

// Top company block. Logo remains square and undistorted.
if (is_file($logo)) { $pdf->imageContain($logo, 222, 690, 150, 150); }

// Company contact block: split the name/address over shorter lines so it
// does not crowd the central logo, and add clear web/phone contact lines.
$pdf->text(40, 802, 'Dance Thru The', 13, true, $purple);
$pdf->text(40, 787, 'Decades Events', 13, true, $purple);
$pdf->text(40, 766, '1 Cooks Cross', 9.5, false, $dark);
$pdf->text(40, 752, 'Alveley', 9.5, false, $dark);
$pdf->text(40, 738, 'Shropshire', 9.5, false, $dark);
$pdf->text(40, 724, 'WV15 6LS', 9.5, false, $dark);
$pdf->text(40, 702, 'Web:', 9.5, true, $purple);
$pdf->text(72, 702, 'www.dancethruthedecades.co.uk', 9.5, false, $purple);
$pdf->text(40, 686, 'Tel:', 9.5, true, $purple);
$pdf->text(72, 686, '07807 705937', 9.5, false, $purple);

$pdf->text(415, 794, $title, 23, true, $purple);
$pdf->line(415, 780, 555, 780, 0.72);
$pdf->text(415, 758, 'Number:', 9, true, $dark);
$pdf->text(485, 758, (string)$doc['number'], 9, false, $dark);
$pdf->line(415, 749, 555, 749, 0.82);
$pdf->text(415, 732, 'Date:', 9, true, $dark);
$pdf->text(485, 732, date('d/m/Y'), 9, false, $dark);

if ($isPreview) {
    $pdf->rect(185, 665, 225, 18, [1.000, 0.940, 0.780], [1.000, 0.470, 0.110]);
    $pdf->text(208, 671, 'PREVIEW / TEST DOCUMENT - NOT SAVED', 9, true, $purple);
}

// Customer and event cards. These sit closer to the header and allow the
// event venue/address to wrap over more lines without crowding the item table.
$cardY = 530;
$cardH = 122;
$cardHeaderY = $cardY + $cardH - 22;

$pdf->rect(40, $cardY, 247, $cardH, [1,1,1], $line);
$pdf->rect(40, $cardHeaderY, 247, 22, $softPurple, $line);
$pdf->text(54, $cardHeaderY + 7, 'BILL TO', 12, true, $purple);
$pdf->text(54, $cardHeaderY - 18, $doc['customer_name'] ?: 'Customer name', 10, true, $dark);
$y = $cardHeaderY - 36;
foreach (preg_split('/\r\n|\r|\n/', (string)$doc['customer_address']) as $addrLine) {
    $addrLine = trim($addrLine);
    if ($addrLine === '') { continue; }
    $pdf->multiline(54, $y, $addrLine, 8, 38, 10, 1, false, $dark);
    $y -= 10;
    if ($y < $cardY + 18) { break; }
}
if (!empty($doc['customer_email']) && $y >= $cardY + 12) { $pdf->text(54, $y, $doc['customer_email'], 8, false, $purple); }

$pdf->rect(308, $cardY, 247, $cardH, [1,1,1], $line);
$pdf->rect(308, $cardHeaderY, 247, 22, $softPurple, $line);
$pdf->text(322, $cardHeaderY + 7, 'EVENT DETAILS', 12, true, $purple);
$pdf->text(322, $cardHeaderY - 18, 'Event / Occasion:', 8, true, $dark);
$pdf->multiline(404, $cardHeaderY - 18, $doc['event_description'] ?: 'Dance Thru The Decades Event', 8, 30, 10, 2, false, $dark);
$pdf->line(322, $cardHeaderY - 43, 540, $cardHeaderY - 43, 0.82);
$pdf->text(322, $cardHeaderY - 54, 'Event Date:', 8, true, $dark);
$pdf->multiline(404, $cardHeaderY - 54, dttd_pdf_event_date_time($doc['event_date'], $doc['event_start_time'], $doc['event_end_time']), 8, 30, 10, 2, false, $dark);
$pdf->line(322, $cardHeaderY - 78, 540, $cardHeaderY - 78, 0.82);
$pdf->text(322, $cardHeaderY - 90, 'Venue:', 8, true, $dark);
$pdf->multiline(404, $cardHeaderY - 90, $doc['venue'] ?: 'TBC', 8, 31, 10, 4, false, $dark);

// Line item table with fewer blank rows to free vertical space for the footer artwork.
$pdf->rect(40, 485, 515, 23, $purple, $purple);
$pdf->text(54, 493, 'DESCRIPTION', 10, true, [1,1,1]);
$pdf->text(478, 493, 'AMOUNT', 10, true, [1,1,1]);

$y = 453;
$total = 0;
$maxRows = 4;
$row = 0;
foreach ($doc['items'] as $item) {
    if ($row >= $maxRows) { break; }
    $price = (float)($item['price'] ?? 0);
    $total += $price;
    $pdf->rect(40, $y-6, 410, 32, [1,1,1], $line);
    $pdf->rect(450, $y-6, 105, 32, [1,1,1], $line);
    $pdf->multiline(54, $y+9, (string)($item['description'] ?? ''), 8, 68, 10, 2, false, $dark);
    $pdf->textRight(535, $y+5, dttd_pdf_money($price), 9, true, $dark);
    $y -= 32;
    $row++;
}
while ($row < 3) {
    $pdf->rect(40, $y-6, 410, 32, [1,1,1], $line);
    $pdf->rect(450, $y-6, 105, 32, [1,1,1], $line);
    $y -= 32;
    $row++;
}

// Notes and payment schedule area compacted to leave a clean full-width footer.
$pdf->text(40, 300, 'NOTES / PAYMENT TERMS', 10, true, $purple);
$pdf->rect(40, 195, 220, 90, [1,1,1], $line);
$notes = trim((string)$doc['notes']);
if ($notes === '') {
    $notes = 'Thank you for booking Dance Thru The Decades Events.';
}
$pdf->multiline(54, 265, $notes, 8, 42, 11, 6, false, $dark);

$quoteDateTs = !empty($doc['quote_date']) ? strtotime($doc['quote_date']) : time();
if ($quoteDateTs === false) { $quoteDateTs = time(); }
$depositPercent = max(0, min(100, (float)($doc['deposit_percentage'] ?? 20)));
$eventDateTs = !empty($doc['event_date']) ? strtotime($doc['event_date']) : false;
$depositDue = 'N/A';
if ($depositPercent > 0) {
    $depositDueTs = !empty($doc['deposit_due_date']) ? strtotime($doc['deposit_due_date']) : strtotime('+30 days', $quoteDateTs);
    $depositDue = $depositDueTs ? date('d/m/Y', $depositDueTs) : date('d/m/Y', strtotime('+30 days', $quoteDateTs));
}
$balanceDueTs = !empty($doc['balance_due_date']) ? strtotime($doc['balance_due_date']) : false;
if (!$balanceDueTs && !empty($doc['balance_due_event_date']) && $eventDateTs) { $balanceDueTs = $eventDateTs; }
if (!$balanceDueTs && $eventDateTs) { $balanceDueTs = strtotime('-14 days', $eventDateTs); }
$balanceDue = $balanceDueTs ? date('d/m/Y', $balanceDueTs) : '14 days before event';
$bookingDeposit = round($total * ($depositPercent / 100), 2);
$remainingBalance = max(0, $total - $bookingDeposit);
$depositLabel = 'BOOKING DEPOSIT';
$depositValue = $depositPercent > 0 ? (rtrim(rtrim(number_format($depositPercent, 2), '0'), '.') . '% / ' . dttd_pdf_money($bookingDeposit)) : 'Not required';

if ($type === 'invoice') {
    $summaryRows = [
        ['TOTAL INVOICE', dttd_pdf_money($total), [1,1,1], $purple],
        ['AMOUNT PAID', dttd_pdf_money(0), [1,1,1], $line],
        ['BALANCE DUE', dttd_pdf_money($total), $purple, $purple],
    ];
} else {
    $summaryRows = [
        ['TOTAL QUOTATION', dttd_pdf_money($total), $softGold, $line],
        ['BOOKING DEPOSIT', $depositValue, [1,1,1], $line],
    ];
    if ($depositPercent > 0) {
        $summaryRows[] = ['DEPOSIT DUE BY', $depositDue, [1,1,1], $line];
        $summaryRows[] = ['REMAINING BALANCE', dttd_pdf_money($remainingBalance), [1,1,1], $line];
    }
    $summaryRows[] = ['BALANCE DUE BY', $balanceDue, $purple, $purple];
}

// Payment summary aligned with the top of the notes box. The value column is
// right-aligned and the font size is uniform so the rows read cleanly.
$summaryX = 278;
$summaryY = 285;
$summaryW = 277;
$rowH = $type === 'invoice' ? 30 : 24;
$labelX = $summaryX + 12;
$valueRightX = $summaryX + $summaryW - 14;
$summaryFont = 9.6;
foreach ($summaryRows as $summaryRow) {
    [$label, $value, $fill, $stroke] = $summaryRow;
    $pdf->rect($summaryX, $summaryY - $rowH, $summaryW, $rowH, $fill, $stroke);
    $textColour = ($fill === $purple) ? [1,1,1] : $dark;
    $labelColour = ($fill === $purple) ? [1,1,1] : $purple;
    $pdf->text($labelX, $summaryY - $rowH + 8, $label, $summaryFont, true, $labelColour);
    $pdf->textRight($valueRightX, $summaryY - $rowH + 8, (string)$value, $summaryFont, true, $textColour);
    $summaryY -= $rowH;
}

$pdf->text(40, 155, $isPreview ? 'Preview mode: this document was not saved and no quote or invoice number has been allocated.' : 'Generated by Dance Thru The Decades Events.', 8, false, $purple);

$pdf->endPage();
$pdf->output(strtolower(str_replace(' ', '-', $title)) . '-' . preg_replace('/[^A-Za-z0-9-]/', '', $doc['number']) . '.pdf');
